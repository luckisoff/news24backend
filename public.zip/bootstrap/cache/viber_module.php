<?php return array (
  'providers' => 
  array (
    0 => 'App\\Viber\\Providers\\ViberServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'App\\Viber\\Providers\\ViberServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);