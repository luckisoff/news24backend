<?php return array (
  'providers' => 
  array (
    0 => 'App\\Finance\\Providers\\FinanceServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'App\\Finance\\Providers\\FinanceServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);