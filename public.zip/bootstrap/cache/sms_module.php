<?php return array (
  'providers' => 
  array (
    0 => 'App\\Sms\\Providers\\SmsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'App\\Sms\\Providers\\SmsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);