<?php return array (
  'providers' => 
  array (
    0 => 'App\\LeaderRegistration\\Providers\\LeaderRegistrationServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'App\\LeaderRegistration\\Providers\\LeaderRegistrationServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);