<?php return array (
  'providers' => 
  array (
    0 => 'App\\News\\Providers\\NewsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'App\\News\\Providers\\NewsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);