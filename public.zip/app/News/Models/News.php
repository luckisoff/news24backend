<?php

namespace App\News\Models;

use Illuminate\Database\Eloquent\Model;

class news extends Model
{
    protected $guarded = [];
}
