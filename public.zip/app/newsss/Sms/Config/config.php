<?php

return [
    'name' => 'Sms'
];
