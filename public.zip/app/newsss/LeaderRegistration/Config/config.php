<?php

return [
    'name' => 'LeaderRegistration'
];
