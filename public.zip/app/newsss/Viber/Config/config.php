<?php

return [
    'name' => 'Viber'
];
